OBJETS AU SOL - Gen1Recomp 0.1.98+
===================================

Compatibilite : Pokemon Rouge, Bleu et Jaune.

Ce que fait le mod
------------------
Les objets caches qui n'ont pas encore ete ramasses sont signales sur la
carte par un petit losange anime. Appuyez sur A depuis la case du losange ou
une case directement voisine : l'orientation du personnage n'a pas
d'importance. Les objets deja visibles sous forme de Poke Ball restent
inchanges. Le marqueur disparait des que l'objet est pris.

Installation
------------
1. Ne modifiez et ne deplacez pas vos ROM pour ce mod.
2. Copiez le dossier "Objets-au-sol-Gen1Recomp-1.0.0" ou son fichier ZIP
   dans le dossier de mods utilise par Gen1Recomp.
3. Ouvrez le gestionnaire de mods, activez "Objets au sol", puis relancez
   la partie si le gestionnaire le demande.

Important
---------
Le mod n'ouvre, ne patche et ne reecrit aucune ROM. Il utilise exclusivement
les donnees de carte que Gen1Recomp a deja chargees en memoire.
